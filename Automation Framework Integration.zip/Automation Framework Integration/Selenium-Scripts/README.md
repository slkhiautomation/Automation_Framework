### What is this repository for? ###
For Automated tests of VineyardVines

### Contribution guidelines ###
Definition of Done
1)Totally isolated each test i.e. any automated test should not depend on previous test data
2)testcases part of everyday Jenkins launch automated launch

### Who do I talk to? ###
Farhan Sheikh

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions